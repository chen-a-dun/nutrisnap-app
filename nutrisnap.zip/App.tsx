
import React, { useState, useEffect } from 'react';
import { AppScreen, Meal, UserStats } from './types';
import SplashScreen from './screens/SplashScreen';
import Dashboard from './screens/Dashboard';
import CameraScreen from './screens/CameraScreen';
import AnalysisScreen from './screens/AnalysisScreen';
import ProfileScreen from './screens/ProfileScreen';

const INITIAL_MEALS: Meal[] = [
  {
    id: '1',
    name: 'Avocado Toast',
    type: 'Breakfast',
    time: '8:30 AM',
    calories: 350,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD6YqwaCL4FcFtJPWVx6GrJ0UTNW2vxP3Eg-RpNRTT02VIJDSo9SW9kJ2V24cLXBdlk9ZBu-x84mR5LwV7h77SSvHnTjZqKIDaunc7l3sHEK_67Yi1AvaCYcMtOJw_2HtU5qXrPA3UO4sLjfK4ALWfC1oEaDGnqEvDX4jAmucr4PXo63C9e1EayREO7DPVfiX-OjqgN8Tt8i1MxIVd3S8eoWTQ6NGBbHyQLUI_Cjv8H9B_QXlruQ1BauTemh6-0t-9e7NnQk1aI0lc',
    macros: { protein: 12, carbs: 45, fats: 20 },
    ingredients: [{ name: 'Avocado', calories: 160 }, { name: 'Poached Egg', calories: 70 }, { name: 'Sourdough', calories: 220 }]
  },
  {
    id: '2',
    name: 'Grilled Chicken Salad',
    type: 'Lunch',
    time: '12:45 PM',
    calories: 420,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCJybJ0HjD7iuF0RN-d3dqvKi_jZrCrei3qXXOY4lEStaAlSEQaK8PMEFAq9Rv1f_2w8TIBR_ogW19XVUE9Xk8-DRFVDG3b9iho5RimhT3tgjDXQPtZzF7Bnh9DaJRdpwCJlpYUqCdqPHYSszlbRy88cOanaXNbWuFRel3c1hfyGhyCuNsc7iD9tp7S71uC33Rb7pr4dPY58rU0iV5fP_EyrJecyiKwCcwbbZTXMceh8SxMT96nHu4jNL8Urq9_5OMnQmfefXCEABA',
    macros: { protein: 35, carbs: 10, fats: 15 },
    ingredients: [{ name: 'Chicken Breast', calories: 200 }, { name: 'Mixed Greens', calories: 50 }, { name: 'Dressing', calories: 170 }]
  }
];

const INITIAL_STATS: UserStats = {
  dailyGoal: 2000,
  eaten: 770,
  burned: 450,
  macros: { protein: 47, carbs: 55, fats: 35 },
  macroGoals: { protein: 120, carbs: 200, fats: 60 },
  streak: 12,
  weightLost: 3.5
};

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>(AppScreen.SPLASH);
  const [meals, setMeals] = useState<Meal[]>(INITIAL_MEALS);
  const [stats, setStats] = useState<UserStats>(INITIAL_STATS);
  const [pendingMeal, setPendingMeal] = useState<Partial<Meal> | null>(null);

  useEffect(() => {
    if (currentScreen === AppScreen.SPLASH) {
      const timer = setTimeout(() => setCurrentScreen(AppScreen.DASHBOARD), 2500);
      return () => clearTimeout(timer);
    }
  }, [currentScreen]);

  const handleSaveMeal = (meal: Meal) => {
    setMeals(prev => [meal, ...prev]);
    setStats(prev => ({
      ...prev,
      eaten: prev.eaten + meal.calories,
      macros: {
        protein: prev.macros.protein + meal.macros.protein,
        carbs: prev.macros.carbs + meal.macros.carbs,
        fats: prev.macros.fats + meal.macros.fats,
      }
    }));
    setCurrentScreen(AppScreen.DASHBOARD);
    setPendingMeal(null);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case AppScreen.SPLASH:
        return <SplashScreen />;
      case AppScreen.DASHBOARD:
        return (
          <Dashboard 
            stats={stats} 
            meals={meals} 
            onNavigate={setCurrentScreen} 
          />
        );
      case AppScreen.CAMERA:
        return (
          <CameraScreen 
            onClose={() => setCurrentScreen(AppScreen.DASHBOARD)} 
            onCapture={(data) => {
              setPendingMeal(data);
              setCurrentScreen(AppScreen.ANALYSIS);
            }} 
          />
        );
      case AppScreen.ANALYSIS:
        return (
          <AnalysisScreen 
            mealData={pendingMeal} 
            onClose={() => setCurrentScreen(AppScreen.DASHBOARD)} 
            onSave={handleSaveMeal}
          />
        );
      case AppScreen.PROFILE:
        return (
          <ProfileScreen 
            stats={stats} 
            onNavigate={setCurrentScreen} 
          />
        );
      default:
        return <SplashScreen />;
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white dark:bg-background-dark min-h-screen relative shadow-2xl overflow-hidden flex flex-col">
      {renderScreen()}
    </div>
  );
};

export default App;
