
import React from 'react';
import { Meal } from '../types';

interface AnalysisScreenProps {
  mealData: Partial<Meal> | null;
  onClose: () => void;
  onSave: (meal: Meal) => void;
}

const AnalysisScreen: React.FC<AnalysisScreenProps> = ({ mealData, onClose, onSave }) => {
  if (!mealData) return null;

  const handleSave = () => {
    onSave({
      ...mealData as Meal,
      id: Math.random().toString(36).substr(2, 9),
    });
  };

  return (
    <div className="relative flex flex-col h-full w-full overflow-hidden bg-background-light dark:bg-background-dark">
      {/* Header */}
      <div className="flex items-center p-4 pb-2 justify-between z-10">
        <button 
          onClick={onClose}
          className="flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-black/5 dark:hover:bg-white/10"
        >
          <span className="material-symbols-outlined text-text-main dark:text-white" style={{ fontSize: '24px' }}>arrow_back_ios_new</span>
        </button>
        <h2 className="text-text-main dark:text-white text-lg font-bold flex-1 text-center pr-10">Analysis Result</h2>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto pb-32 no-scrollbar">
        <div className="px-4 py-2">
          <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden shadow-lg shadow-primary/10 group">
            <div 
              className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" 
              style={{ backgroundImage: `url("${mealData.image || 'https://picsum.photos/600/400'}")` }}
            ></div>
            <div className="absolute top-4 right-4 bg-white/90 dark:bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-sm border border-white/20">
              <span className="material-symbols-outlined text-primary" style={{ fontSize: '18px', fontVariationSettings: "'FILL' 1" }}>check_circle</span>
              <span className="text-xs font-bold text-gray-800 dark:text-gray-200 uppercase tracking-wide">High Confidence</span>
            </div>
          </div>
        </div>

        <div className="px-6 pt-6 pb-2 text-center">
          <h1 className="text-text-main dark:text-white text-3xl font-extrabold leading-tight tracking-tight">
            {mealData.name}<br/>
            {mealData.subtitle && <span className="text-gray-400 dark:text-gray-500 font-medium text-2xl">{mealData.subtitle}</span>}
          </h1>
        </div>

        <div className="flex items-center justify-center gap-8 px-6 py-6">
          <div className="flex flex-col items-center">
            <div className="relative flex items-baseline">
              <span className="text-primary text-7xl font-black tracking-tighter leading-none">{mealData.calories}</span>
            </div>
            <span className="text-gray-500 dark:text-gray-400 font-bold text-lg uppercase tracking-widest mt-1">kcal</span>
          </div>
          <div className="w-px h-20 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
          <div className="flex flex-col items-center gap-2">
            <div className="relative size-24">
              <svg className="rotate-[-90deg]" viewBox="0 0 100 100">
                <circle className="dark:stroke-gray-800" cx="50" cy="50" fill="transparent" r="40" stroke="#f0f0f0" strokeWidth="12"></circle>
                <circle cx="50" cy="50" fill="transparent" r="40" stroke="#9ebf8d" strokeDasharray="160 251.2" strokeLinecap="round" strokeWidth="12"></circle>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="material-symbols-outlined text-primary" style={{ fontSize: '24px' }}>nutrition</span>
              </div>
            </div>
          </div>
        </div>

        <div className="px-4">
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Protein', val: mealData.macros?.protein, color: 'bg-primary' },
              { label: 'Carbs', val: mealData.macros?.carbs, color: 'bg-yellow-200' },
              { label: 'Fat', val: mealData.macros?.fats, color: 'bg-gray-300' }
            ].map(macro => (
              <div key={macro.label} className="bg-cream-yellow dark:bg-[#2C3328] p-4 rounded-2xl flex flex-col items-center justify-center gap-1 shadow-sm border border-transparent dark:border-white/5">
                <div className={`size-2 rounded-full ${macro.color} mb-1`}></div>
                <p className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{macro.label}</p>
                <p className="text-xl font-bold text-gray-900 dark:text-white">{macro.val}g</p>
              </div>
            ))}
          </div>
        </div>

        <div className="px-5 mt-6 mb-4">
          <h3 className="text-sm font-bold text-text-main dark:text-white mb-3">Detected Ingredients</h3>
          <div className="flex flex-col gap-2">
            {mealData.ingredients?.map((ing, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 rounded-xl border border-gray-100 dark:border-white/10 bg-white dark:bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="size-8 rounded-lg bg-gray-100 dark:bg-white/10 flex items-center justify-center">
                    {idx === 0 ? '🥑' : idx === 1 ? '🥚' : '🍞'}
                  </div>
                  <span className="text-sm font-medium">{ing.name}</span>
                </div>
                <span className="text-sm text-gray-500 dark:text-gray-400">{ing.calories} kcal</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 w-full bg-white/80 dark:bg-[#181c16]/80 backdrop-blur-xl border-t border-gray-100 dark:border-white/5 p-6 pb-8 z-20">
        <div className="flex gap-4">
          <button 
            onClick={onClose}
            className="flex-1 py-4 px-6 rounded-2xl border-2 border-primary/30 text-primary hover:bg-primary/5 active:scale-95 transition-all font-bold text-base flex items-center justify-center gap-2"
          >
            <span className="material-symbols-outlined">edit</span>
            Edit
          </button>
          <button 
            onClick={handleSave}
            className="flex-[2] py-4 px-6 rounded-2xl bg-primary hover:bg-primary-dark text-white shadow-lg shadow-primary/25 active:scale-95 transition-all font-bold text-base flex items-center justify-center gap-2"
          >
            <span className="material-symbols-outlined">add_circle</span>
            Save to Log
          </button>
        </div>
      </div>
    </div>
  );
};

export default AnalysisScreen;
