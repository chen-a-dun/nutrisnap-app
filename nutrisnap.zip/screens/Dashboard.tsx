
import React from 'react';
import { UserStats, Meal, AppScreen } from '../types';

interface DashboardProps {
  stats: UserStats;
  meals: Meal[];
  onNavigate: (screen: AppScreen) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ stats, meals, onNavigate }) => {
  const caloriesLeft = stats.dailyGoal - stats.eaten;
  const progressPercent = Math.min(1, stats.eaten / stats.dailyGoal);
  const circumference = 2 * Math.PI * 42;
  const dashOffset = circumference - (circumference * progressPercent);

  return (
    <div className="relative flex-1 w-full flex flex-col pb-28 bg-white dark:bg-background-dark overflow-y-auto no-scrollbar">
      {/* Header */}
      <header className="flex items-center justify-between px-6 pt-12 pb-4">
        <div className="flex flex-col">
          <p className="text-text-muted dark:text-gray-400 text-sm font-medium mb-0.5">
            {new Date().toLocaleDateString('en-US', { weekday: 'short', day: 'numeric', month: 'short' })}
          </p>
          <h1 className="text-2xl font-bold tracking-tight text-text-main dark:text-white">Good Morning, Alex</h1>
        </div>
        <button 
          onClick={() => onNavigate(AppScreen.PROFILE)}
          className="h-12 w-12 rounded-full bg-gray-200 overflow-hidden border-2 border-white dark:border-gray-700 shadow-sm relative group"
        >
          <img className="h-full w-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDMz8NE9DvIkUNiU4_zBy7z2u_Ef9E9p4lKYiYbfsdoawM7hyGv9OvijPRe0l4-UxXj6FUKz2Ldhr1RS8G0E6XTBsWdLF-2Z5wh4mWJIM9NlT39ZCkFOE7ovp-UQHd9qfmtCVOx3EjwpKyf7W-Vp25Uw7twTUuo8pMJys_sqkf2fwmaVYsE5_K2Rg0kZHOP2jn-ISpAQGmDSZdvmVhpvlK_5MNk8gW47vLRJUZ7whWPqMxKiIU2Gc5mMBqHf3EV4fZ90ZPFy3XtMmo" alt="User" />
        </button>
      </header>

      {/* Main Calorie Chart */}
      <section className="flex flex-col items-center justify-center py-6 relative">
        <div className="relative w-64 h-64">
          <div className="absolute inset-0 bg-primary/10 rounded-full blur-3xl scale-75 dark:bg-primary/5"></div>
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle className="text-gray-100 dark:text-gray-800" cx="50" cy="50" fill="transparent" r="42" stroke="currentColor" strokeWidth="8"></circle>
            <circle 
              className="text-primary transition-all duration-1000 ease-out" 
              cx="50" cy="50" fill="transparent" r="42" stroke="currentColor" 
              strokeDasharray={circumference} 
              strokeDashoffset={dashOffset} 
              strokeLinecap="round" strokeWidth="8"
            ></circle>
            <circle 
              className="text-accent dark:text-yellow-600/50" cx="50" cy="50" fill="transparent" r="42" stroke="#F8F4E3" 
              strokeDasharray={circumference} 
              strokeDashoffset={circumference - (circumference * 0.1)} 
              strokeLinecap="round" strokeWidth="8" 
              style={{ transform: 'rotate(140deg)', transformOrigin: '50% 50%' }}
            ></circle>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="text-4xl font-extrabold text-text-main dark:text-white tracking-tight">
              {caloriesLeft.toLocaleString()}
            </span>
            <span className="text-sm font-medium text-text-muted dark:text-gray-400 mt-1 uppercase tracking-wide">kcal left</span>
          </div>
        </div>
        <div className="flex items-center gap-6 mt-2">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-primary"></div>
            <span className="text-xs font-medium text-text-muted dark:text-gray-400">Eaten</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-cream-yellow dark:bg-yellow-600/50 border border-gray-100 dark:border-transparent"></div>
            <span className="text-xs font-medium text-text-muted dark:text-gray-400">Burned</span>
          </div>
        </div>
      </section>

      {/* Macro Cards */}
      <section className="px-6 py-4">
        <div className="flex gap-4 overflow-x-auto pb-4 -mx-6 px-6 no-scrollbar">
          {[
            { label: 'Protein', key: 'protein', icon: 'egg_alt', color: 'bg-primary', iconBg: 'bg-primary/10' },
            { label: 'Carbs', key: 'carbs', icon: 'bakery_dining', color: 'bg-yellow-400', iconBg: 'bg-yellow-100' },
            { label: 'Fats', key: 'fats', icon: 'water_drop', color: 'bg-orange-400', iconBg: 'bg-orange-50' }
          ].map(macro => (
            <div key={macro.key} className="flex-1 min-w-[140px] bg-white dark:bg-stone-900 rounded-2xl p-4 shadow-soft border border-stone-50 dark:border-stone-800 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className={`p-2 ${macro.iconBg} rounded-lg text-primary`}>
                  <span className="material-symbols-outlined text-[20px]">{macro.icon}</span>
                </div>
                <span className="text-xs font-bold text-text-muted dark:text-gray-500">
                  {Math.round((stats.macros[macro.key as keyof typeof stats.macros] / stats.macroGoals[macro.key as keyof typeof stats.macroGoals]) * 100)}%
                </span>
              </div>
              <div>
                <p className="text-sm font-medium text-text-muted dark:text-gray-400">{macro.label}</p>
                <p className="text-lg font-bold text-text-main dark:text-white mt-0.5">
                  {stats.macros[macro.key as keyof typeof stats.macros]}g
                  <span className="text-xs font-normal text-gray-400 ml-1">/{stats.macroGoals[macro.key as keyof typeof stats.macroGoals]}g</span>
                </p>
              </div>
              <div className="h-1.5 w-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                <div className={`h-full ${macro.color} rounded-full`} style={{ width: `${(stats.macros[macro.key as keyof typeof stats.macros] / stats.macroGoals[macro.key as keyof typeof stats.macroGoals]) * 100}%` }}></div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Meals List */}
      <section className="px-6 mt-2">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-text-main dark:text-white tracking-tight">Today's Meals</h3>
          <button className="text-sm font-semibold text-primary hover:text-primary/80 transition-colors">View all</button>
        </div>
        <div className="flex flex-col gap-3">
          {meals.map(meal => (
            <div key={meal.id} className="group flex items-center justify-between p-3 bg-white dark:bg-stone-900 rounded-2xl shadow-soft border border-transparent hover:border-primary/20 transition-all cursor-pointer">
              <div className="flex items-center gap-4">
                <div 
                  className="h-16 w-16 rounded-xl bg-gray-100 bg-cover bg-center shrink-0" 
                  style={{ backgroundImage: `url("${meal.image || 'https://picsum.photos/200'}")` }}
                ></div>
                <div className="flex flex-col gap-1">
                  <p className="text-text-main dark:text-white font-bold text-base leading-tight">{meal.name}</p>
                  <p className="text-text-muted dark:text-gray-400 text-xs font-medium">{meal.type} • {meal.time}</p>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1 pr-1">
                <span className="text-primary font-bold text-base">{meal.calories}</span>
                <span className="text-xs text-text-muted dark:text-gray-500">kcal</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Bottom Nav / FAB */}
      <div className="fixed bottom-0 left-0 w-full z-50">
        <div className="absolute bottom-[4.5rem] left-1/2 -translate-x-1/2 pointer-events-none w-full flex justify-center">
          <button 
            onClick={() => onNavigate(AppScreen.CAMERA)}
            className="pointer-events-auto h-16 w-16 bg-primary hover:bg-[#8dae7d] text-white rounded-full shadow-[0_8px_20px_rgba(158,191,141,0.5)] flex items-center justify-center transition-transform hover:scale-105 active:scale-95 group relative overflow-hidden"
          >
            <span className="absolute inset-0 bg-white/20 rounded-full scale-0 group-hover:scale-150 transition-transform duration-500 ease-out"></span>
            <span className="material-symbols-outlined text-[32px]">photo_camera</span>
          </button>
        </div>
        <nav className="h-[88px] w-full bg-white/90 dark:bg-stone-900/90 backdrop-blur-lg border-t border-stone-100 dark:border-stone-800 flex items-start justify-between px-8 pt-4 pb-8 shadow-[0_-4px_20px_rgba(0,0,0,0.02)]">
          <button onClick={() => onNavigate(AppScreen.DASHBOARD)} className="flex flex-col items-center gap-1 w-12 text-primary">
            <span className="material-symbols-outlined font-semibold">home</span>
            <span className="text-[10px] font-medium">Home</span>
          </button>
          <button className="flex flex-col items-center gap-1 w-12 text-text-muted dark:text-gray-500 hover:text-primary transition-colors">
            <span className="material-symbols-outlined">menu_book</span>
            <span className="text-[10px] font-medium">Logs</span>
          </button>
          <div className="w-16"></div>
          <button className="flex flex-col items-center gap-1 w-12 text-text-muted dark:text-gray-500 hover:text-primary transition-colors">
            <span className="material-symbols-outlined">analytics</span>
            <span className="text-[10px] font-medium">Stats</span>
          </button>
          <button onClick={() => onNavigate(AppScreen.PROFILE)} className="flex flex-col items-center gap-1 w-12 text-text-muted dark:text-gray-500 hover:text-primary transition-colors">
            <span className="material-symbols-outlined">person</span>
            <span className="text-[10px] font-medium">Profile</span>
          </button>
        </nav>
      </div>
    </div>
  );
};

export default Dashboard;
