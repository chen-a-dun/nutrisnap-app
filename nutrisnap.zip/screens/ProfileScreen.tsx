
import React from 'react';
import { UserStats, AppScreen } from '../types';

interface ProfileScreenProps {
  stats: UserStats;
  onNavigate: (screen: AppScreen) => void;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ stats, onNavigate }) => {
  return (
    <div className="relative flex flex-col h-full w-full flex-col pb-24 bg-background-light dark:bg-background-dark overflow-y-auto no-scrollbar">
      {/* Top App Bar */}
      <div className="flex items-center p-6 justify-between z-10">
        <button 
          onClick={() => onNavigate(AppScreen.DASHBOARD)}
          className="flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-black/5 dark:hover:bg-white/10"
        >
          <span className="material-symbols-outlined text-text-main dark:text-white">arrow_back_ios_new</span>
        </button>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/50 dark:bg-black/20 backdrop-blur-md">
          <span className="text-sm font-bold tracking-wide uppercase text-primary">Profile</span>
        </div>
        <button className="flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-black/5 dark:hover:bg-white/10">
          <span className="material-symbols-outlined text-text-main dark:text-white">settings</span>
        </button>
      </div>

      {/* Profile Header */}
      <div className="flex flex-col items-center px-6 pt-2 pb-8">
        <div className="relative group cursor-pointer">
          <div className="absolute inset-0 bg-primary/30 rounded-full blur-xl scale-90 group-hover:scale-105 transition-transform duration-500"></div>
          <div className="relative p-1.5 bg-white dark:bg-stone-900 rounded-full shadow-soft">
            <div className="w-28 h-28 rounded-full overflow-hidden border-2 border-primary/20">
              <img alt="Sarah" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDy8Eq6CwzR0PddTU0Bvx_hR1RjyWVw71jrHXfUfiH1NjmilaOZrtEAN1DKN4WoGtmUMG4kgfsAe-5Sx7ZphoFn8AUVWPJzuitpce9AQQrkG9V9J2jU-q2o0Qq2wLTBeZoZihNAgCF00FhmnkDIo5_2B0m2HSW8ukfaYoVAmDbRmieUjIv4BYed4hgkQA8h8VvIv5JEkHu0KQCd40I4lq1dD8HA-BSu1b9OgbEdI6-V5YzXoCw7mhLIkN24g8KyJl4U90DZUnqtmx4" />
            </div>
            <div className="absolute bottom-1 right-1 bg-primary text-white p-1.5 rounded-full border-2 border-white dark:border-stone-900 flex items-center justify-center shadow-md">
              <span className="material-symbols-outlined text-[16px] font-bold">edit</span>
            </div>
          </div>
        </div>
        <div className="mt-5 text-center">
          <h1 className="text-2xl font-bold tracking-tight text-text-main dark:text-white">Sarah Jenkins</h1>
          <p className="text-text-muted dark:text-gray-400 text-sm mt-1 font-medium">Calorie Conscious since Jan 2023</p>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex flex-col gap-6 px-5">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white dark:bg-stone-900 rounded-3xl p-5 shadow-soft flex flex-col justify-between h-32 relative overflow-hidden group">
            <div className="absolute -right-4 -top-4 w-16 h-16 bg-primary/10 rounded-full group-hover:bg-primary/20 transition-colors"></div>
            <div className="flex items-center gap-2 z-10">
              <span className="material-symbols-outlined text-primary">local_fire_department</span>
              <p className="text-sm font-semibold text-text-muted dark:text-gray-400">Streak</p>
            </div>
            <div className="z-10">
              <p className="text-3xl font-extrabold text-text-main dark:text-white">{stats.streak}</p>
              <p className="text-xs text-text-muted dark:text-gray-400 font-medium">Days active</p>
            </div>
          </div>
          <div className="bg-white dark:bg-stone-900 rounded-3xl p-5 shadow-soft flex flex-col justify-between h-32 relative overflow-hidden group">
            <div className="absolute -right-4 -bottom-4 w-16 h-16 bg-blue-100 dark:bg-blue-900/20 rounded-full"></div>
            <div className="flex items-center gap-2 z-10">
              <span className="material-symbols-outlined text-blue-400">monitor_weight</span>
              <p className="text-sm font-semibold text-text-muted dark:text-gray-400">Lost</p>
            </div>
            <div className="z-10">
              <p className="text-3xl font-extrabold text-text-main dark:text-white">-{stats.weightLost}</p>
              <p className="text-xs text-text-muted dark:text-gray-400 font-medium">Kilograms</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-stone-900 rounded-[2rem] p-6 shadow-soft">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-text-main dark:text-white">October 2023</h3>
            <div className="flex gap-2">
              <button className="p-1.5 rounded-full hover:bg-background-light dark:hover:bg-stone-800 text-text-muted transition-colors">
                <span className="material-symbols-outlined text-xl">chevron_left</span>
              </button>
              <button className="p-1.5 rounded-full hover:bg-background-light dark:hover:bg-stone-800 text-text-muted transition-colors">
                <span className="material-symbols-outlined text-xl">chevron_right</span>
              </button>
            </div>
          </div>
          <div className="grid grid-cols-7 gap-y-4 mb-2">
            {['S','M','T','W','T','F','S'].map(d => (
              <div key={d} className="text-center text-xs font-bold text-text-muted dark:text-gray-500 uppercase tracking-wide">{d}</div>
            ))}
            {[...Array(3)].map((_,i) => <div key={`empty-${i}`}></div>)}
            {[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18].map(day => (
              <button key={day} className="flex flex-col items-center gap-1 group relative">
                {day === 5 && <div className="absolute -inset-2 bg-primary/10 dark:bg-primary/20 rounded-xl -z-10"></div>}
                <span className={`text-sm font-medium ${day === 5 ? 'text-primary font-bold' : 'text-text-main dark:text-white'}`}>{day}</span>
                <div className={`size-1.5 rounded-full ${day % 3 === 0 ? 'bg-primary' : 'bg-gray-200 dark:bg-gray-700'}`}></div>
              </button>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-center gap-6">
            <div className="flex items-center gap-2">
              <div className="size-2 rounded-full bg-primary"></div>
              <span className="text-xs text-text-muted dark:text-gray-400 font-medium">Goal Met</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="size-2 rounded-full bg-gray-200 dark:bg-gray-700"></div>
              <span className="text-xs text-text-muted dark:text-gray-400 font-medium">Rest/Miss</span>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-stone-900 rounded-[2rem] p-2 shadow-soft flex flex-col mb-10">
          <button className="flex items-center justify-between p-4 rounded-3xl hover:bg-background-light dark:hover:bg-background-dark/50 transition-colors group">
            <div className="flex items-center gap-4">
              <div className="size-10 rounded-full bg-orange-100 dark:bg-orange-900/20 flex items-center justify-center text-orange-600 dark:text-orange-400">
                <span className="material-symbols-outlined">flag</span>
              </div>
              <div className="text-left">
                <p className="text-base font-bold text-text-main dark:text-white">My Goals</p>
                <p className="text-xs text-text-muted dark:text-gray-400">Daily calorie limits</p>
              </div>
            </div>
            <span className="material-symbols-outlined text-text-muted group-hover:translate-x-1 transition-transform">chevron_right</span>
          </button>
          <div className="h-px bg-background-light dark:bg-stone-800 mx-4"></div>
          <button className="flex items-center justify-between p-4 rounded-3xl hover:bg-background-light dark:hover:bg-background-dark/50 transition-colors group">
            <div className="flex items-center gap-4">
              <div className="size-10 rounded-full bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center text-purple-600 dark:text-purple-400">
                <span className="material-symbols-outlined">restaurant_menu</span>
              </div>
              <div className="text-left">
                <p className="text-base font-bold text-text-main dark:text-white">Food Preferences</p>
                <p className="text-xs text-text-muted dark:text-gray-400">Allergies & diets</p>
              </div>
            </div>
            <span className="material-symbols-outlined text-text-muted group-hover:translate-x-1 transition-transform">chevron_right</span>
          </button>
        </div>
      </div>

      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
        <button 
          onClick={() => onNavigate(AppScreen.CAMERA)}
          className="flex items-center gap-2 bg-text-main dark:bg-white text-white dark:text-background-dark pl-5 pr-6 py-3.5 rounded-full shadow-float hover:scale-105 active:scale-95 transition-all duration-300"
        >
          <span className="material-symbols-outlined">photo_camera</span>
          <span className="font-bold text-sm tracking-wide">Log Meal</span>
        </button>
      </div>
    </div>
  );
};

export default ProfileScreen;
