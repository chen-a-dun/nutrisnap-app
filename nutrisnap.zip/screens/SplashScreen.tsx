
import React from 'react';

const SplashScreen: React.FC = () => {
  return (
    <div className="relative flex flex-1 flex-col items-center justify-between overflow-hidden bg-white dark:bg-background-dark">
      <div className="h-16 w-full"></div>
      
      <div className="relative z-10 flex flex-col items-center justify-center w-full px-6">
        <div className="relative mb-10 group cursor-default">
          <div className="absolute inset-0 bg-primary/20 blur-2xl rounded-full transform scale-150 opacity-40 dark:opacity-20"></div>
          <div className="relative flex items-center justify-center w-36 h-36 bg-white dark:bg-zinc-800 rounded-[2.5rem] shadow-soft-float border border-slate-50 dark:border-zinc-700">
            <div className="absolute w-24 h-24 rounded-full border border-primary/10 dark:border-primary/20"></div>
            <div className="absolute w-28 h-28 rounded-full border border-primary/5 dark:border-primary/10 rotate-45"></div>
            <div className="relative flex items-center justify-center text-primary">
              <span className="material-symbols-outlined text-7xl opacity-20 absolute" style={{ fontVariationSettings: "'wght' 200" }}>
                camera
              </span>
              <span className="material-symbols-outlined text-6xl relative z-10 drop-shadow-sm text-primary">
                spa
              </span>
            </div>
            <div className="absolute top-8 right-8 w-3 h-3 bg-cream-yellow rounded-full border-2 border-white dark:border-zinc-800"></div>
          </div>
        </div>
        
        <div className="text-center space-y-2 max-w-xs mx-auto">
          <h1 className="text-[#141613] dark:text-white tracking-tight text-4xl font-bold leading-tight">
            NutriSnap
          </h1>
          <p className="text-[#737c6e] dark:text-zinc-400 text-base font-medium tracking-wide">
            Snap. Track. Thrive.
          </p>
        </div>
      </div>

      <div className="relative w-full pb-12 pt-20 flex flex-col items-center justify-end z-0">
        <div className="absolute bottom-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute bottom-[-20%] left-[-10%] w-[70%] h-[80%] bg-cream-yellow rounded-full blur-[80px] opacity-60 dark:opacity-5 mix-blend-multiply dark:mix-blend-normal"></div>
          <div className="absolute bottom-[-30%] right-[-10%] w-[80%] h-[90%] bg-primary/30 rounded-full blur-[100px] opacity-70 dark:opacity-20"></div>
        </div>
        
        <div className="relative z-10 flex flex-col items-center gap-3 opacity-80">
          <div className="flex items-center gap-1.5 h-4">
            <div className="w-1.5 h-1.5 rounded-full bg-primary/40 animate-pulse"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse delay-75"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-primary/40 animate-pulse delay-150"></div>
          </div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-[#737c6e] dark:text-zinc-500 font-bold">
            Initializing
          </p>
        </div>
        <div className="h-4 w-full"></div>
      </div>
    </div>
  );
};

export default SplashScreen;
