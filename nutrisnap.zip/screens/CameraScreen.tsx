
import React, { useRef, useEffect, useState } from 'react';
import { analyzeFoodImage } from '../services/geminiService';
import { Meal } from '../types';

interface CameraScreenProps {
  onClose: () => void;
  onCapture: (meal: Partial<Meal>) => void;
}

const CameraScreen: React.FC<CameraScreenProps> = ({ onClose, onCapture }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [hasCamera, setHasCamera] = useState(false);

  useEffect(() => {
    async function startCamera() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment' } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setHasCamera(true);
        }
      } catch (err) {
        console.error("Camera access error:", err);
      }
    }
    startCamera();
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || isAnalyzing) return;
    
    setIsAnalyzing(true);
    const canvas = canvasRef.current;
    const video = videoRef.current;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const base64Image = canvas.toDataURL('image/jpeg').split(',')[1];
      
      try {
        const analyzedMeal = await analyzeFoodImage(base64Image);
        onCapture({ ...analyzedMeal, image: canvas.toDataURL('image/jpeg') });
      } catch (error) {
        console.error("Analysis error:", error);
        alert("Could not analyze image. Please try again.");
      } finally {
        setIsAnalyzing(false);
      }
    }
  };

  return (
    <div className="absolute inset-0 bg-black flex flex-col items-center justify-between z-50 select-none overflow-hidden">
      {/* Camera Feed */}
      <div className="absolute inset-0 z-0">
        {hasCamera ? (
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted 
            className="w-full h-full object-cover opacity-95"
          />
        ) : (
          <img 
            alt="Simulated Viewfinder" 
            className="w-full h-full object-cover opacity-95" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAoIkCK1soIriXxcEh2CDz4thvtex299O-0MJTKcCXlR3hrgrlB4HOkmLIlWYII8j9er-sC-p1oBkUpORRYkBoxXAf-oKg08kdlASaNkNRNaNKn0Zuu1mQpuEw7ZQegTQJ0YW0oy-VGp5VV5VvV7dtiTJtYHQO5Ou2DNGdp8h7EnA5MVrfKa86t2-TjDZ9FLiTWScFsU5JtdWq7qRFzAws4HajLlTS8NZYQ4ihge7by3nz9MsuRcu6w23mUvXOZWzqbQv_zvN1Bpcg"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/70 pointer-events-none"></div>
      </div>

      <canvas ref={canvasRef} className="hidden" />

      {/* Interface */}
      <div className="relative z-10 flex flex-col h-full justify-between w-full max-w-md mx-auto">
        <div className="flex items-center justify-between p-6 pt-12">
          <button 
            onClick={onClose}
            className="group flex items-center justify-center size-10 rounded-full bg-white/10 backdrop-blur-md text-white hover:bg-white/20 transition-all active:scale-95 border border-white/10 shadow-lg"
          >
            <span className="material-symbols-outlined text-2xl group-hover:rotate-90 transition-transform duration-300">close</span>
          </button>
          
          <div className="flex items-center gap-2 px-3 py-1 bg-black/30 backdrop-blur-sm rounded-full border border-white/5">
            <div className={`size-2 rounded-full ${isAnalyzing ? 'bg-yellow-400' : 'bg-green-400'} animate-pulse`}></div>
            <span className="text-xs font-medium text-white/80 tracking-wide uppercase">
              {isAnalyzing ? 'Analyzing...' : 'AI Active'}
            </span>
          </div>
          
          <button className="flex items-center justify-center size-10 rounded-full bg-white/10 backdrop-blur-md text-white border border-white/10 shadow-lg group">
            <span className="material-symbols-outlined text-2xl group-hover:text-yellow-200">flash_on</span>
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center relative w-full px-8">
          <div className="relative w-full aspect-square max-w-[320px] border border-white/30 rounded-[2rem] shadow-2xl overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent shadow-[0_0_20px_rgba(158,191,141,0.6)] animate-scan z-20"></div>
            <div className="absolute top-0 left-0 w-8 h-8 border-t-[3px] border-l-[3px] border-white rounded-tl-2xl z-10"></div>
            <div className="absolute top-0 right-0 w-8 h-8 border-t-[3px] border-r-[3px] border-white rounded-tr-2xl z-10"></div>
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-[3px] border-l-[3px] border-white rounded-bl-2xl z-10"></div>
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-[3px] border-r-[3px] border-white rounded-br-2xl z-10"></div>
            <div className="absolute inset-0 w-full h-full opacity-10 grid grid-cols-3 grid-rows-3 pointer-events-none">
              <div className="border-r border-b border-white"></div>
              <div className="border-r border-b border-white"></div>
              <div className="border-b border-white"></div>
              <div className="border-r border-b border-white"></div>
              <div className="border-r border-b border-white"></div>
              <div className="border-b border-white"></div>
              <div className="border-r border-white"></div>
              <div className="border-r border-white"></div>
              <div></div>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center pb-8 pt-4 w-full bg-gradient-to-t from-black/80 via-black/40 to-transparent">
          <div className="mb-8">
            <p className="text-white/90 text-sm font-medium tracking-wider drop-shadow-md bg-white/10 px-6 py-2 rounded-full backdrop-blur-md border border-white/5">
              Center food in frame
            </p>
          </div>
          <div className="flex items-center justify-between w-full px-10 pb-6 max-w-[400px]">
            <button className="relative flex items-center justify-center group">
              <div className="size-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center overflow-hidden transition-all duration-300 group-hover:bg-white/20 shadow-lg">
                <img alt="Gallery" className="w-full h-full object-cover opacity-80" src="https://picsum.photos/100" />
              </div>
            </button>
            
            <button 
              onClick={capturePhoto}
              disabled={isAnalyzing}
              className="relative size-[88px] rounded-full border-[3px] border-white/40 flex items-center justify-center transition-all duration-200 active:scale-95 hover:border-white/60 group shadow-xl"
            >
              <div className="absolute inset-0 rounded-full bg-white/5 blur-md group-hover:bg-white/10"></div>
              <div className="size-[72px] rounded-full bg-primary shadow-inner flex items-center justify-center relative overflow-hidden">
                <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-bl from-white/30 via-transparent to-black/10 opacity-60"></div>
                <span className="material-symbols-outlined text-white text-3xl drop-shadow-sm">photo_camera</span>
              </div>
            </button>
            
            <button className="flex items-center justify-center group">
              <div className="size-14 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white transition-all duration-300 group-hover:bg-white/20 shadow-lg">
                <span className="material-symbols-outlined text-2xl group-hover:text-primary">info</span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CameraScreen;
