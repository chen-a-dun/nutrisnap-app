
export enum AppScreen {
  SPLASH = 'SPLASH',
  DASHBOARD = 'DASHBOARD',
  CAMERA = 'CAMERA',
  ANALYSIS = 'ANALYSIS',
  PROFILE = 'PROFILE'
}

export interface MacroStats {
  protein: number;
  carbs: number;
  fats: number;
}

export interface Ingredient {
  name: string;
  calories: number;
  icon?: string;
}

export interface Meal {
  id: string;
  name: string;
  subtitle?: string;
  type: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
  time: string;
  calories: number;
  image?: string;
  macros: MacroStats;
  ingredients: Ingredient[];
}

export interface UserStats {
  dailyGoal: number;
  eaten: number;
  burned: number;
  macros: MacroStats;
  macroGoals: MacroStats;
  streak: number;
  weightLost: number;
}
