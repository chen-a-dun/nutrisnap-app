
# NutriSnap - Snap. Track. Thrive.

NutriSnap 是一款高端饮食追踪应用，利用 Google Gemini API 的强大视觉能力，通过照片识别食物并自动计算热量与宏量营养素（蛋白质、碳水、脂肪）。

## ✨ 功能特性

- **AI 食物识别**：拍摄或上传照片，实时分析食物成分。
- **宏量营养素追踪**：自动记录每日蛋白质、碳水化合物和脂肪摄入。
- **精美仪表盘**：直观展示每日剩余热量预算。
- **历史记录管理**：查看过往餐食详情及成分拆解。
- **现代化 UI**：采用 Plus Jakarta Sans 字体与磨砂玻璃质感设计。

## 🛠️ 技术栈

- **框架**: React 19
- **样式**: Tailwind CSS
- **AI 能力**: Google Gemini API (@google/genai)
- **语言**: TypeScript

## 🚀 快速开始

1. **克隆仓库**:
   ```bash
   git clone https://github.com/your-username/nutrisnap.git
   cd nutrisnap
   ```

2. **配置环境变量**:
   在项目根目录创建 `.env` 文件并添加你的 API Key：
   ```env
   API_KEY=你的_GEMINI_API_KEY
   ```

3. **运行项目**:
   由于项目使用了 ES Modules 导入，建议使用 Vite 或其他现代开发服务器运行。

## 📸 屏幕快照

- **Splash**: 品牌启动动画
- **Dashboard**: 每日营养概览
- **Camera**: AI 视觉扫描界面
- **Analysis**: 深度营养成分拆解

---
*Developed with Google Gemini API.*
