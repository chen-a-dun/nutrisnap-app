
import { GoogleGenAI, Type } from "@google/genai";
import { Meal, MacroStats, Ingredient } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeFoodImage = async (base64Image: string): Promise<Partial<Meal>> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [
      {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image,
            },
          },
          {
            text: "Analyze this food image. Provide the food name, a short subtitle if applicable, estimated calories, protein (g), carbs (g), fat (g), and a list of detected ingredients with their estimated calorie counts. Format the response as JSON.",
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          subtitle: { type: Type.STRING },
          calories: { type: Type.NUMBER },
          protein: { type: Type.NUMBER },
          carbs: { type: Type.NUMBER },
          fats: { type: Type.NUMBER },
          ingredients: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                calories: { type: Type.NUMBER },
              },
              required: ["name", "calories"],
            },
          },
        },
        required: ["name", "calories", "protein", "carbs", "fats", "ingredients"],
      },
    },
  });

  const data = JSON.parse(response.text || '{}');

  return {
    name: data.name,
    subtitle: data.subtitle,
    calories: data.calories,
    macros: {
      protein: data.protein,
      carbs: data.carbs,
      fats: data.fats,
    },
    ingredients: data.ingredients,
    type: 'Lunch', // Default
    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  };
};
